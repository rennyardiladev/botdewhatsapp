import express, { type Request, type Response, type NextFunction } from 'express';
import type { TenantManager } from './core/TenantManager.js';
import type { Database } from './database/Database.js';
import { TenantQueue } from './core/TenantQueue.js';

export function createHttpApp(options: {
  tenantManager: TenantManager;
  db: Database;
  apiToken: string;
  queue: TenantQueue;
}) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '256kb' }));

  app.get('/health', (_req, res) => res.json({ ok: true, uptimeSeconds: process.uptime() }));

  app.use('/api', (req: Request, res: Response, next: NextFunction) => {
    const auth = req.header('authorization') ?? '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
    if (!options.apiToken || options.apiToken === 'replace-with-a-long-random-secret') {
      res.status(503).json({ error: 'Configura API_TOKEN en .env antes de usar la API' });
      return;
    }
    if (token.length !== options.apiToken.length ||
        !Buffer.from(token).equals(Buffer.from(options.apiToken))) {
      res.status(401).json({ error: 'No autorizado' });
      return;
    }
    next();
  });

  app.get('/api/tenants', (_req, res) => res.json({ tenants: options.tenantManager.listTenants() }));

  app.post('/api/tenants', (req, res) => {
    const body = req.body as { id?: unknown; name?: unknown; config?: unknown };
    if (typeof body.id !== 'string' || typeof body.name !== 'string') {
      res.status(400).json({ error: 'Se requieren id y name como texto' });
      return;
    }
    try {
      const tenant = options.tenantManager.createTenant({
        id: body.id,
        name: body.name,
        config: body.config && typeof body.config === 'object' ? body.config as never : {}
      });
      res.status(201).json({ tenant });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Error creando tenant' });
    }
  });

  app.get('/api/tenants/:id/status', (req, res) => {
    const status = options.tenantManager.getStatus(req.params.id);
    if (!status) { res.status(404).json({ error: 'Tenant no encontrado' }); return; }
    res.json(status);
  });

  app.post('/api/tenants/:id/start', async (req, res) => {
    try {
      await options.tenantManager.startTenant(req.params.id);
      res.json({ ok: true, status: options.tenantManager.getStatus(req.params.id) });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'No se pudo iniciar' });
    }
  });

  app.post('/api/tenants/:id/stop', async (req, res) => {
    await options.tenantManager.stopTenant(req.params.id);
    res.json({ ok: true });
  });

  app.delete('/api/tenants/:id', async (req, res) => {
    const deleted = await options.tenantManager.deleteTenant(req.params.id);
    if (!deleted) { res.status(404).json({ error: 'Tenant no encontrado' }); return; }
    res.json({ ok: true, note: 'Los archivos de sesión se conservan por seguridad.' });
  });

  app.get('/api/tenants/:id/messages', (req, res) => {
    if (!options.tenantManager.getTenant(req.params.id)) {
      res.status(404).json({ error: 'Tenant no encontrado' });
      return;
    }
    const limit = Number(req.query.limit ?? 50);
    res.json({ messages: options.db.getRecentMessages(req.params.id, Number.isFinite(limit) ? limit : 50) });
  });

  app.get('/api/metrics', (_req, res) => {
    const memory = process.memoryUsage();
    res.json({
      uptimeSeconds: process.uptime(),
      tenantCount: options.tenantManager.listTenants().length,
      connected: options.tenantManager.listTenants().filter((t) => t.status === 'open').length,
      memory: {
        rssMB: Math.round(memory.rss / 1024 / 1024),
        heapUsedMB: Math.round(memory.heapUsed / 1024 / 1024),
        heapTotalMB: Math.round(memory.heapTotal / 1024 / 1024)
      },
      queue: options.queue.metrics()
    });
  });

  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error('HTTP error:', error);
    res.status(500).json({ error: 'Error interno' });
  });

  return app;
}