import DatabaseSync from 'better-sqlite3';
import type { TenantConfig, BotStatus } from '../types.js';
import type { TenantRecord } from '../core/TenantInstance.js';

export interface StoredMessage {
  tenantId: string;
  jid: string;
  direction: 'incoming' | 'outgoing';
  text: string;
  messageId: string | null;
}

export class Database {
  private readonly db: DatabaseSync.Database;

  constructor(filePath: string) {
    this.db = new DatabaseSync(filePath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('foreign_keys = ON');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS tenants (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        config_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS tenant_status (
        tenant_id TEXT PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,
        status TEXT NOT NULL DEFAULT 'stopped',
        details_json TEXT,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        jid TEXT NOT NULL,
        direction TEXT NOT NULL,
        text TEXT NOT NULL,
        message_id TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_messages_tenant_created ON messages(tenant_id, created_at);
      CREATE INDEX IF NOT EXISTS idx_messages_tenant_jid ON messages(tenant_id, jid);
    `);
  }

  createTenant(id: string, name: string, config: TenantConfig): TenantRecord {
    const createdAt = new Date().toISOString();
    this.db.prepare('INSERT INTO tenants (id, name, config_json, created_at) VALUES (?, ?, ?, ?)')
      .run(id, name, JSON.stringify(config), createdAt);
    this.setStatus(id, 'stopped');
    return { id, name, config, createdAt };
  }

  listTenants(): TenantRecord[] {
    const rows = this.db.prepare('SELECT id, name, config_json, created_at FROM tenants ORDER BY created_at').all() as Array<{
      id: string; name: string; config_json: string; created_at: string
    }>;
    return rows.map((row) => ({ id: row.id, name: row.name, config: JSON.parse(row.config_json) as TenantConfig, createdAt: row.created_at }));
  }

  getTenant(id: string): TenantRecord | undefined {
    const row = this.db.prepare('SELECT id, name, config_json, created_at FROM tenants WHERE id = ?').get(id) as {
      id: string; name: string; config_json: string; created_at: string
    } | undefined;
    return row ? { id: row.id, name: row.name, config: JSON.parse(row.config_json) as TenantConfig, createdAt: row.created_at } : undefined;
  }

  setStatus(id: string, status: BotStatus | string, details?: Record<string, unknown>): void {
    this.db.prepare(`
      INSERT INTO tenant_status (tenant_id, status, details_json, updated_at) VALUES (?, ?, ?, ?)
      ON CONFLICT(tenant_id) DO UPDATE SET status=excluded.status, details_json=excluded.details_json, updated_at=excluded.updated_at
    `).run(id, status, details ? JSON.stringify(details) : null, new Date().toISOString());
  }

  getStatus(id: string): string | undefined {
    const row = this.db.prepare('SELECT status FROM tenant_status WHERE tenant_id = ?').get(id) as { status: string } | undefined;
    return row?.status;
  }

  saveMessage(message: StoredMessage): void {
    this.db.prepare(`
      INSERT INTO messages (tenant_id, jid, direction, text, message_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(message.tenantId, message.jid, message.direction, message.text.slice(0, 10000), message.messageId, new Date().toISOString());
  }

  getRecentMessages(tenantId: string, limit = 50): unknown[] {
    const safeLimit = Math.max(1, Math.min(200, Math.trunc(limit)));
    return this.db.prepare(`
      SELECT jid, direction, text, message_id AS messageId, created_at AS createdAt
      FROM messages WHERE tenant_id = ? ORDER BY id DESC LIMIT ?
    `).all(tenantId, safeLimit);
  }

  deleteTenant(id: string): boolean {
    return this.db.prepare('DELETE FROM tenants WHERE id = ?').run(id).changes > 0;
  }

  close(): void { this.db.close(); }
}