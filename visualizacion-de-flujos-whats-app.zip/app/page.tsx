'use client'

import { useMemo, useState } from 'react'
import {
  Bot,
  Check,
  ChevronDown,
  CircleHelp,
  Eye,
  MessageCircle,
  MoreVertical,
  Plus,
  Send,
  Smartphone,
  Trash2,
  UserRound,
  Zap,
} from 'lucide-react'

const initialSteps = [
  { id: 1, trigger: 'hola', response: '¡Hola! Soy el asistente virtual de Mi Bot 👋' },
  { id: 2, trigger: '1', response: 'Perfecto. ¿En qué podemos ayudarte hoy?' },
]

export default function Page() {
  const [steps, setSteps] = useState(initialSteps)
  const [activeStep, setActiveStep] = useState(2)
  const [trigger, setTrigger] = useState('')
  const [response, setResponse] = useState('')

  const active = steps.find((step) => step.id === activeStep) ?? steps[steps.length - 1]
  const previewMessages = useMemo(() => {
    const visible = steps.slice(0, Math.max(activeStep, 1))
    return visible.flatMap((step, index) => [
      ...(index === 0 ? [] : [{ type: 'user' as const, text: step.trigger }]),
      { type: 'bot' as const, text: step.response },
    ])
  }, [steps, activeStep])

  function addStep() {
    if (!trigger.trim() || !response.trim()) return
    const next = { id: steps.length + 1, trigger: trigger.trim(), response: response.trim() }
    setSteps((current) => [...current, next])
    setActiveStep(next.id)
    setTrigger('')
    setResponse('')
  }

  function deleteStep(id: number) {
    const next = steps.filter((step) => step.id !== id)
    setSteps(next)
    setActiveStep(next[Math.max(0, next.length - 1)]?.id ?? 1)
  }

  return (
    <main className="min-h-screen bg-[#f4f7f6] text-[#17221f]">
      <header className="border-b border-[#dfe7e3] bg-white">
        <div className="mx-auto flex max-w-[1380px] items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-xl bg-[#d9fdd3] text-[#128c7e]"><MessageCircle /></div>
            <div><p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#66736e]">Mi Bot</p><h1 className="text-lg font-semibold">Flujos de WhatsApp</h1></div>
          </div>
          <div className="flex items-center gap-3 text-sm text-[#66736e]"><span className="hidden sm:block">Instancia activa</span><button className="flex items-center gap-2 rounded-lg border border-[#dfe7e3] bg-white px-3 py-2 font-medium text-[#17221f]">whatsapp1 <ChevronDown size={15} /></button><div className="size-8 rounded-full bg-[#d9fdd3] p-1.5 text-[#128c7e]"><UserRound size={20} /></div></div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1380px] gap-7 px-6 py-8 lg:grid-cols-[minmax(0,1fr)_430px]">
        <section>
          <div className="mb-7 flex items-end justify-between"><div><p className="mb-2 flex items-center gap-2 text-sm font-medium text-[#128c7e]"><Zap size={16} /> Constructor visual</p><h2 className="text-3xl font-semibold tracking-tight">Crea tu flujo paso a paso</h2><p className="mt-2 text-[#66736e]">Mira en tiempo real cómo se verá la conversación en WhatsApp.</p></div><button className="hidden items-center gap-2 rounded-lg border border-[#dfe7e3] bg-white px-4 py-2.5 text-sm font-medium md:flex"><Eye size={16} /> Vista previa</button></div>

          <div className="rounded-2xl border border-[#dfe7e3] bg-white p-5 shadow-[0_8px_30px_rgba(25,71,54,0.05)] sm:p-6">
            <div className="mb-6 flex items-center justify-between border-b border-[#edf1ef] pb-5"><div><h3 className="font-semibold">Secuencia del flujo</h3><p className="mt-1 text-sm text-[#66736e]">Cada tarjeta representa una respuesta automática.</p></div><span className="rounded-full bg-[#eff9ed] px-3 py-1 text-xs font-semibold text-[#128c7e]">{steps.length} pasos</span></div>
            <div className="flex flex-col gap-0">
              {steps.map((step, index) => <div key={step.id} className="relative flex gap-4"><div className="flex w-8 shrink-0 flex-col items-center"><button onClick={() => setActiveStep(step.id)} className={`z-10 flex size-8 items-center justify-center rounded-full border-2 text-sm font-semibold transition ${activeStep === step.id ? 'border-[#128c7e] bg-[#128c7e] text-white' : 'border-[#d9e6e0] bg-white text-[#7a8881]'}`}>{activeStep > step.id ? <Check size={15} /> : step.id}</button>{index !== steps.length - 1 && <div className="h-full min-h-8 w-px bg-[#dfe7e3]" />}</div><div className={`mb-4 flex-1 rounded-xl border p-4 transition ${activeStep === step.id ? 'border-[#9ed9a2] bg-[#fbfffb] shadow-sm' : 'border-[#e7eeea] bg-[#fcfdfc]'}`}><div className="flex items-start justify-between gap-4"><div><div className="mb-2 flex items-center gap-2"><span className="text-xs font-semibold uppercase tracking-wider text-[#7a8881]">Cuando escriben</span><span className="rounded-md bg-[#e8f5e8] px-2 py-0.5 text-sm font-semibold text-[#128c7e]">{step.trigger}</span></div><p className="text-[15px] leading-6 text-[#33423a]">{step.response}</p></div><button onClick={() => deleteStep(step.id)} aria-label={`Eliminar paso ${step.id}`} className="rounded-md p-1.5 text-[#a3afaa] hover:bg-[#fff1f0] hover:text-red-500"><Trash2 size={16} /></button></div></div></div>)}
            </div>

            <div className="mt-2 rounded-xl border border-dashed border-[#b9d7c0] bg-[#f8fcf8] p-4"><div className="mb-4 flex items-center gap-2 text-sm font-semibold text-[#128c7e]"><Plus size={16} /> Añadir nuevo paso</div><div className="grid gap-3 sm:grid-cols-[150px_1fr_auto]"><div><label className="mb-1.5 block text-xs font-medium text-[#66736e]">Palabra clave</label><input value={trigger} onChange={(event) => setTrigger(event.target.value)} placeholder="ej. ayuda" className="w-full rounded-lg border border-[#dfe7e3] bg-white px-3 py-2.5 text-sm outline-none focus:border-[#128c7e] focus:ring-2 focus:ring-[#d9fdd3]" /></div><div><label className="mb-1.5 block text-xs font-medium text-[#66736e]">Respuesta del bot</label><input value={response} onChange={(event) => setResponse(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.nativeEvent.isComposing && event.keyCode !== 229) addStep() }} placeholder="Escribe el mensaje que recibirá tu cliente..." className="w-full rounded-lg border border-[#dfe7e3] bg-white px-3 py-2.5 text-sm outline-none focus:border-[#128c7e] focus:ring-2 focus:ring-[#d9fdd3]" /></div><button onClick={addStep} className="mt-auto flex items-center justify-center gap-2 rounded-lg bg-[#128c7e] px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-[#0d766a]"><Plus size={16} /> Añadir</button></div></div>
          </div>
        </section>

        <aside className="lg:sticky lg:top-6 lg:self-start"><div className="mb-4 flex items-center justify-between"><div><p className="flex items-center gap-2 text-sm font-medium text-[#128c7e]"><Smartphone size={16} /> Vista en vivo</p><h2 className="mt-1 text-xl font-semibold">Así lo verá tu cliente</h2></div><span className="flex items-center gap-1.5 text-xs text-[#128c7e]"><span className="size-2 rounded-full bg-[#25d366]" /> En directo</span></div><div className="mx-auto w-full max-w-[370px] rounded-[40px] bg-[#17221f] p-3 shadow-[0_20px_55px_rgba(25,71,54,0.22)]"><div className="overflow-hidden rounded-[31px] bg-[#efeae2]"><div className="flex items-center justify-between bg-[#075e54] px-5 py-3 text-white"><div className="flex items-center gap-3"><div className="flex size-9 items-center justify-center rounded-full bg-[#d9fdd3] text-[#128c7e]"><Bot size={19} /></div><div><p className="text-sm font-semibold">Mi Bot</p><p className="text-[10px] text-white/70">en línea</p></div></div><MoreVertical size={18} /></div><div className="flex min-h-[500px] flex-col justify-end gap-3 bg-[radial-gradient(#d8d0c6_0.7px,transparent_0.7px)] bg-[length:13px_13px] p-4"><div className="mb-auto rounded-lg bg-[#fff8c5] px-3 py-2 text-center text-[10px] text-[#82775a] shadow-sm">Hoy</div>{previewMessages.map((message, index) => <div key={`${message.text}-${index}`} className={`max-w-[86%] rounded-lg px-3 py-2 text-[13px] leading-5 shadow-sm ${message.type === 'user' ? 'self-end rounded-tr-none bg-[#d9fdd3] text-[#26382d]' : 'self-start rounded-tl-none bg-white text-[#26382d]'}`}><p>{message.text}</p><div className="mt-1 flex justify-end items-center gap-1 text-[9px] text-[#82918a]">10:2{index} <span className="text-[#53bdeb]">{message.type === 'user' ? '✓✓' : ''}</span></div></div>)}<div className="flex items-center gap-2 rounded-full bg-white px-4 py-3 text-xs text-[#82918a] shadow-sm"><span>Escribe un mensaje</span><Send className="ml-auto text-[#128c7e]" size={16} /></div></div></div></div><p className="mt-4 text-center text-xs text-[#7a8881]">El teléfono se actualiza mientras construyes tu flujo</p></aside>
      </div>
    </main>
  )
}
